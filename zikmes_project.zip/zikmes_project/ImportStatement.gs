/**
 * ============================================================
 *  ИМПОРТ ВЫПИСКИ БАНКА (HTML) — НОВЫЙ БЛОК, добавляется к существующему коду
 * ============================================================
 *
 * Этот блок НЕ изменяет и не использует существующие функции/переменные
 * (doGet, doPost, getPendingRows_, markProcessed_, formatDate_, pad2_,
 * COL_*, METHOD_FILTER, STATUS_DONE, MIN_AMOUNT, jsonResponse).
 * Он добавляет свои отдельные точки входа и не пересекается со старым кодом.
 *
 * УСТАНОВКА:
 * 1. Откройте Extensions -> Apps Script в таблице "Оплаты Зикмес".
 * 2. В файле Code.gs (где уже лежит старый код) добавьте этот файл КАК ОТДЕЛЬНЫЙ
 *    .gs файл: "+" рядом с "Файлы" -> "Script" -> назовите, например, ImportStatement.
 *    Вставьте туда весь этот код.
 * 3. Создайте ещё один файл (HTML) с именем ImportStatementPage (см. соответствующий
 *    файл ImportStatementPage.html) - это страница-загрузчик.
 * 4. Сохраните (значок дискеты).
 * 5. Чтобы открыть страницу загрузки, разверните веб-приложение ещё раз
 *    (Развернуть -> Управление развертываниями -> карандаш -> Новая версия -> Развернуть),
 *    ИЛИ откройте напрямую через "Выполнить" -> запустите функцию getImportPageUrl_
 *    и посмотрите URL в журнале (см. инструкцию ниже).
 *
 * КАК ПОЛЬЗОВАТЬСЯ:
 * 1. Зайдите в банк, авторизуйтесь, откройте выписку, сохраните страницу как HTML
 *    (правой кнопкой -> "Сохранить как" -> формат "Веб-страница, только HTML").
 * 2. Откройте URL веб-приложения с параметром ?page=import, например:
 *    https://script.google.com/macros/s/XXXXX/exec?page=import
 * 3. На открывшейся странице нажмите "Выбрать файл", выберите сохранённый .html файл.
 * 4. Нажмите "Показать превью" - скрипт распарсит файл и покажет таблицу
 *    с тем, что будет добавлено, БЕЗ записи в таблицу.
 * 5. Проверьте превью. Если всё верно - нажмите "Вставить в таблицу".
 *    Строки добавятся в КОНЕЦ активного листа таблицы "Оплаты Зикмес"
 *    (с пустой строкой-разделителем перед новым блоком дат), столбец F останется
 *    пустым (его заполнит существующий скрипт/Tampermonkey как обычно).
 */

// ---- Константы только для этого блока (намеренно с суффиксом _IMPORT, чтобы не пересекаться) ----
var IMPORT_COL_DATE = 1;     // A
var IMPORT_COL_FIO = 2;      // B
var IMPORT_COL_ORDER_ID = 3; // C
var IMPORT_COL_AMOUNT = 4;   // D
var IMPORT_COL_METHOD = 5;   // E
// Столбец F (статус) этим блоком НИКОГДА не заполняется - он остаётся пустым,
// как и оговорено, чтобы существующий скрипт/фильтр сам проставил "Обработан".

var IMPORT_METHOD_VALUE = 'Расчётный счёт';

/**
 * Роутер для GET-запросов этого блока. Не пересекается с существующим doGet,
 * так как существующий doGet проверяет action='getPending', а здесь смотрим
 * параметр page='import'. Если вы будете объединять с существующим doGet -
 * просто добавьте проверку в начало существующей функции (см. инструкцию ниже),
 * либо, как сделано тут, можно оставить раздельно и объединить вручную одной строкой.
 */
function doGet_importRouter(e) {
  var page = e.parameter.page;
  if (page === 'import') {
    return HtmlService.createHtmlOutputFromFile('ImportStatementPage')
      .setTitle('Импорт выписки банка')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }
  return null; // не наша зона ответственности - пусть основной doGet решает
}

/**
 * Вызывается со страницы-загрузчика (google.script.run).
 * Принимает текст HTML-файла (строка), возвращает массив распарсенных строк
 * для показа в превью. НИЧЕГО не пишет в таблицу.
 */
function previewStatementImport(htmlText) {
  var parsed = parseStatementHtml_(htmlText);
  return {
    rows: parsed.rows,
    skippedErip: parsed.skippedErip,
    skippedCourt: parsed.skippedCourt,
    duplicatesRemoved: parsed.duplicatesRemoved
  };
}

/**
 * Вызывается со страницы-загрузчика после подтверждения.
 * Принимает тот же массив rows, что вернул previewStatementImport (на случай,
 * если человек поправил что-то в превью вручную - но в текущей версии страницы
 * правка не предусмотрена, передаются те же данные).
 * Записывает их в конец активного листа.
 */
function commitStatementImport(rows) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();

  // ВАЖНО: sheet.getLastRow() в Google Sheets может вернуть "раздутое" число,
  // если где-то в листе остались артефакты форматирования или правил
  // валидации (например, выпадающий список), даже когда видимый текст
  // в ячейке пуст. Поэтому мы НЕ используем getLastRow() для поиска точки
  // вставки. Вместо этого читаем столбец A (даты) напрямую на всю реальную
  // высоту листа - дата является самым надёжным признаком того, что в строке
  // есть настоящая запись платежа.
  var maxRows = sheet.getMaxRows(); // реальное физическое число строк на листе
  var colA = sheet.getRange(1, IMPORT_COL_DATE, maxRows, 1).getValues();

  var lastContentRow = 0;
  for (var r = colA.length - 1; r >= 0; r--) {
    var v = colA[r][0];
    if (v !== '' && v !== null) {
      lastContentRow = r + 1;
      break;
    }
  }

  // Дополнительная проверка: если в столбце A пусто, но есть данные в B/C/D
  // (на случай отсутствия даты в какой-то строке) - расширяем поиск этими
  // столбцами тоже.
  if (lastContentRow === 0) {
    var colBCD = sheet.getRange(1, IMPORT_COL_FIO, maxRows, 3).getValues();
    for (var r2 = colBCD.length - 1; r2 >= 0; r2--) {
      var b = colBCD[r2][0], c = colBCD[r2][1], d = colBCD[r2][2];
      if ((b !== '' && b !== null) || (c !== '' && c !== null) || (d !== '' && d !== null)) {
        lastContentRow = r2 + 1;
        break;
      }
    }
  }

  // ВРЕМЕННАЯ ДИАГНОСТИКА: собираем подробности, чтобы понять, что происходит,
  // если результат снова окажется неожиданным. Возвращается на страницу.
  var debugInfo = {
    sheetName: sheet.getName(),
    getLastRowValue: sheet.getLastRow(),
    maxRowsValue: maxRows,
    lastContentRowFound: lastContentRow
  };

  // Дата последней содержательной строки (для сравнения, нужна ли строка-разделитель)
  var lastDateInSheet = null;
  if (lastContentRow > 0) {
    var dateVal = sheet.getRange(lastContentRow, IMPORT_COL_DATE).getValue();
    if (dateVal !== '' && dateVal !== null) {
      lastDateInSheet = formatDateForCompare_(dateVal);
    }
  }

  var writeRow = lastContentRow + 1;
  var prevDate = lastDateInSheet;
  var firstWriteRow = writeRow; // запоминаем, с какой строки реально начали писать

  for (var i = 0; i < rows.length; i++) {
    var row = rows[i];
    var rowDateCompare = row.date; // уже строка dd.mm.yyyy с превью

    // Если дата новой строки отличается от даты предыдущей записанной строки
    // (и это не самая первая строка в этой партии) - вставляем пустую строку-разделитель
    if (prevDate !== null && rowDateCompare !== prevDate) {
      writeRow++; // оставляем одну пустую строку
      if (i === 0) firstWriteRow = writeRow; // если разделитель встал перед самой первой строкой
    }

    sheet.getRange(writeRow, IMPORT_COL_DATE).setValue(row.date);
    sheet.getRange(writeRow, IMPORT_COL_FIO).setValue(row.fio || '');
    sheet.getRange(writeRow, IMPORT_COL_ORDER_ID).setValue(row.id || '');
    sheet.getRange(writeRow, IMPORT_COL_AMOUNT).setValue(row.amount || '');
    sheet.getRange(writeRow, IMPORT_COL_METHOD).setValue(IMPORT_METHOD_VALUE);
    // Столбец F НЕ трогаем - остаётся пустым

    prevDate = rowDateCompare;
    writeRow++;
  }

  return {
    written: rows.length,
    firstRow: firstWriteRow,
    lastRow: writeRow - 1,
    debug: debugInfo
  };
}

/**
 * ОБЪЕДИНЁННАЯ ТОЧКА ВХОДА: вставляет строки из превью в таблицу 1 (как
 * commitStatementImport), а затем СРАЗУ запускает закрытие платежей по
 * рассрочке (processInstallments из Installments.gs), но ТОЛЬКО для только
 * что вставленного диапазона строк - остальной лист не пересканивается.
 *
 * Требует, чтобы в проекте также был установлен блок Installments.gs
 * (функция processInstallments должна существовать в этом же проекте).
 *
 * Возвращает объединённый отчёт: { written, firstRow, lastRow, installments }
 * где installments - это тот же отчёт, что возвращает processInstallments
 * (processed, notFound, hasNote, ..., timing, details), либо null, если
 * не было вставлено ни одной строки (нечего обрабатывать).
 */
function commitStatementImportAndProcessInstallments(rows) {
  var importResult = commitStatementImport(rows);

  var installmentsResult = null;
  if (importResult.written > 0 && typeof processInstallments === 'function') {
    installmentsResult = processInstallments(importResult.firstRow, importResult.lastRow);
  }

  return {
    written: importResult.written,
    firstRow: importResult.firstRow,
    lastRow: importResult.lastRow,
    debug: importResult.debug,
    installments: installmentsResult
  };
}

function formatDateForCompare_(val) {
  if (val instanceof Date) {
    var d = val.getDate();
    var m = val.getMonth() + 1;
    var y = val.getFullYear();
    return (d < 10 ? '0' + d : d) + '.' + (m < 10 ? '0' + m : m) + '.' + y;
  }
  return String(val || '').trim();
}

// ======================================================================
//  ПАРСЕР HTML ВЫПИСКИ
// ======================================================================

/**
 * Основная функция парсинга. Принимает текст HTML-файла целиком, возвращает
 * {rows: [...], skippedErip: N, skippedCourt: N, duplicatesRemoved: N}
 */
function parseStatementHtml_(htmlText) {
  var lines = htmlToLines_(htmlText);

  // Разбиваем на блоки по строкам, равным "Копия"
  var copyIdx = [];
  for (var i = 0; i < lines.length; i++) {
    if (lines[i] === 'Копия') copyIdx.push(i);
  }

  var blocks = [];
  for (var n = 0; n < copyIdx.length; n++) {
    var start = copyIdx[n];
    var end = (n + 1 < copyIdx.length) ? copyIdx[n + 1] : lines.length;
    blocks.push(lines.slice(start, end));
  }

  var allResults = [];
  var skippedErip = 0;
  var skippedCourt = 0;

  for (var b = 0; b < blocks.length; b++) {
    var block = blocks[b];
    var fullText = block.join(' ');

    // НОВОЕ ПРАВИЛО: если где-либо в тексте блока встречается слово "суд"
    // (как корень слова - "суд", "суда", "судебный", но не как часть другого
    // слова вроде "посуда") - пропускаем блок целиком, независимо от типа
    // платежа. Эта проверка идёт ПЕРВОЙ, до проверки на ЕРИП.
    if (/(?:^|[^а-яёa-z])суд/i.test(fullText)) {
      skippedCourt++;
      continue;
    }

    // ЕРИП по-прежнему пропускается целиком, как и раньше.
    if (/ЕРИП/i.test(fullText)) {
      skippedErip++;
      continue;
    }

    if (block.indexOf('Референс операции:') !== -1) {
      var registryOps = parseRegistryOperations_(block);
      for (var ro = 0; ro < registryOps.length; ro++) {
        allResults.push(registryOps[ro]);
      }
    } else {
      allResults.push(parseStandardBlock_(block));
    }
  }

  // Дедупликация технических дублей (одинаковые date+id+amount+fio)
  var seen = {};
  var deduped = [];
  var duplicatesRemoved = 0;
  for (var k = 0; k < allResults.length; k++) {
    var r = allResults[k];
    var key = [r.date, r.id, r.amount, r.fio].join('|');
    if (seen[key]) {
      duplicatesRemoved++;
      continue;
    }
    seen[key] = true;
    deduped.push(r);
  }

  return {
    rows: deduped,
    skippedErip: skippedErip,
    skippedCourt: skippedCourt,
    duplicatesRemoved: duplicatesRemoved
  };
}

/**
 * Извлекает видимый текст из HTML, построчно (аналог BeautifulSoup get_text('\n')
 * в Python-прототипе). Убирает теги, схлопывает пустые строки, декодирует
 * основные HTML-сущности.
 */
function htmlToLines_(html) {
  // Убираем содержимое <script> и <style> целиком
  var cleaned = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ');

  // Заменяем теги, которые обычно разрывают строку, на перевод строки
  cleaned = cleaned.replace(/<\/(p|div|tr|br|li|h\d)\s*>/gi, '\n');
  cleaned = cleaned.replace(/<(br)\s*\/?>/gi, '\n');
  cleaned = cleaned.replace(/<td[^>]*>/gi, '\n');
  cleaned = cleaned.replace(/<\/td>/gi, '');

  // Убираем все оставшиеся теги
  cleaned = cleaned.replace(/<[^>]+>/g, '\n');

  // Декодируем основные HTML-сущности
  cleaned = cleaned
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\u00a0/g, ' ');

  var rawLines = cleaned.split('\n');
  var lines = [];
  for (var i = 0; i < rawLines.length; i++) {
    var t = rawLines[i].replace(/\s+/g, ' ').trim();
    if (t !== '') lines.push(t);
  }
  return lines;
}

function getValueAfter_(block, label, startIdx) {
  var start = startIdx || 0;
  for (var i = start; i < block.length; i++) {
    if (block[i] === label) {
      return (i + 1 < block.length) ? block[i + 1].trim() : null;
    }
  }
  return null;
}

function normalizeAmount_(raw) {
  if (!raw) return null;
  var s = raw.replace(/\u00a0/g, ' ');
  var m = s.match(/([\d\s]+[.,]\d+)/);
  if (m) {
    return m[1].replace(/\s/g, '').replace(',', '.');
  }
  return null;
}

var ID_RE_IMPORT = /сч[её]т[уе]?\s*(?:номер|№)?\s*(\d{6})\b/i;
var SIX_DIGIT_RE_IMPORT = /\b(\d{6})\b/;

var FIO_STOP_WORDS_IMPORT = {
  'ЗА': 1, 'ПО': 1, 'ОТ': 1, 'ПЛАТЕЖ': 1, 'ПЛАТЕЖИ': 1, 'ПЛАТЕЖА': 1,
  'ПЛАТЕЛЬЩИК': 1, 'ОПЛАТА': 1, 'ОПЛ': 1, 'ДОГ': 1, 'СЧЕТУ': 1, 'СЧЁТУ': 1,
  'СЧЕТ': 1, 'СЧЁТ': 1, 'САДОВУЮ': 1, 'ТЕХНИКУ': 1, 'ОАО': 1, 'ООО': 1,
  'ТОВАР': 1, 'ПРИНЯТЫЙ': 1, 'ПРИНЯТЫЕ': 1, 'ПРИНЯТЫХ': 1, 'СУММА': 1,
  'ДАТА': 1, 'НОМЕР': 1, 'ВИТЕБСКИЙ': 1, 'ВИТЕБСКАЯ': 1, 'РУПС': 1, 'ОС': 1,
  'БЕЗ': 1, 'НДС': 1, 'ЛИЦЕВОЙ': 1, 'АДРЕС': 1, 'ПЕРЕЧИСЛЕНИЕ': 1,
  'ПЕРЕВОД': 1, 'СОГЛАСНО': 1, 'ОКАЗАННОЙ': 1, 'УСЛУГЕ': 1, 'ВСЕ': 1,
  'СУММЫ': 1, 'ВЫЧЕТОМ': 1, 'ЗИКМЕС': 1
};

function stripPunct_(w) {
  return w.replace(/^[^А-ЯЁа-яёA-Za-z]+/, '').replace(/[.,;:()]+$/, '');
}

function isCapitalWord_(stripped) {
  return /^[А-ЯЁ][а-яёА-ЯЁ-]*$/.test(stripped);
}

/**
 * Ищет ФИО в произвольном тексте, разбивая текст на слова (токены) и
 * проверяя каждое потенциальное начало (заглавное слово, не из списка
 * служебных стоп-слов банковских формулировок). Берёт до 3 подряд идущих
 * "хороших" слов (Фамилия Имя [Отчество]). Поддерживает однобуквенные
 * инициалы на 2-3 позиции (напр. "ЗЕМСКОВА В Л"), но не на первой
 * (фамилия не может быть однобуквенной).
 * Известное ограничение: очень редкие нестандартные формулировки могут
 * быть распознаны неточно - такие случаи стоит проверять вручную.
 */
function extractFio_(s) {
  if (!s) return null;
  var rawTokens = s.split(/\s+/).filter(function (w) { return w.length > 0; });
  var tokens = rawTokens.map(stripPunct_);

  for (var i = 0; i < tokens.length; i++) {
    if (!isCapitalWord_(tokens[i])) continue;
    var clean0 = tokens[i].toUpperCase();
    if (FIO_STOP_WORDS_IMPORT[clean0]) continue;
    if (tokens[i].length < 2) continue; // фамилия не может быть однобуквенной

    var words = [tokens[i]];
    for (var j = i + 1; j < Math.min(i + 3, tokens.length); j++) {
      if (!isCapitalWord_(tokens[j])) break;
      var cleanJ = tokens[j].toUpperCase();
      if (FIO_STOP_WORDS_IMPORT[cleanJ]) break;
      words.push(tokens[j]);
    }
    if (words.length >= 2) {
      return words.slice(0, 3).join(' ');
    }
  }
  return null;
}

/**
 * Обычное (одиночное) платёжное поручение.
 */
function parseStandardBlock_(block) {
  var dateVal = getValueAfter_(block, 'Дата:');
  var amountRaw = getValueAfter_(block, 'Сумма и валюта:');

  var fioVal = null;
  for (var i = 0; i < block.length; i++) {
    var m = block[i].match(/Фактический плательщик:\s*(.+)/);
    if (m) {
      fioVal = m[1].replace(/\s*BELARUS\s*$/i, '').trim();
      break;
    }
  }

  // Если "Фактический плательщик" - это сама компания (а не настоящий клиент),
  // ФИО считается не указанным. Эти платёжки всё равно вносятся, просто
  // столбец B остаётся пустым.
  if (fioVal && /ЗИКМЕС/i.test(fioVal)) {
    fioVal = null;
  }

  var naznachenie = '';
  for (var j = 0; j < block.length; j++) {
    var m2 = block[j].match(/^Назначение платежа(?:\s*\(перевода\))?:\s*(.*)/);
    if (m2 && m2[1].trim() !== '') {
      naznachenie = m2[1].trim();
      break;
    }
  }

  if (!fioVal) {
    fioVal = extractFio_(naznachenie);
  }

  var idVal = null;
  var idMatch = naznachenie.match(ID_RE_IMPORT);
  if (idMatch) idVal = idMatch[1];

  return {
    date: dateVal,
    amount: normalizeAmount_(amountRaw),
    fio: fioVal,
    id: idVal,
    source: 'standard'
  };
}

/**
 * Реестровый блок (без слова ЕРИП), может содержать 1+ вложенных операций,
 * каждая начинается с 'Референс операции:'.
 */
function parseRegistryOperations_(block) {
  var refPositions = [];
  for (var i = 0; i < block.length; i++) {
    if (block[i] === 'Референс операции:') refPositions.push(i);
  }
  if (refPositions.length === 0) return [];

  var dateVal = getValueAfter_(block, 'Дата платежного документа:');

  var results = [];
  for (var n = 0; n < refPositions.length; n++) {
    var start = refPositions[n];
    var end = (n + 1 < refPositions.length) ? refPositions[n + 1] : block.length;
    var opLines = block.slice(start, end);

    var amountRaw = getValueAfter_(opLines, 'Сумма:');

    var fioVal = null;
    var schetNLocal = getValueAfter_(opLines, 'Счет N');
    if (schetNLocal) {
      fioVal = extractFio_(schetNLocal);
    }

    var idVal = null;
    var kassirVal = getValueAfter_(opLines, 'Номер кассира:');
    if (kassirVal) {
      var idm = kassirVal.match(SIX_DIGIT_RE_IMPORT);
      if (idm) idVal = idm[1];
    }

    results.push({
      date: dateVal,
      amount: normalizeAmount_(amountRaw),
      fio: fioVal,
      id: idVal,
      source: 'registry'
    });
  }
  return results;
}
