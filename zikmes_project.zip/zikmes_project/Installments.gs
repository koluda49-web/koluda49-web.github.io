/**
 * ============================================================
 *  СВЯЗКА С ТАБЛИЦЕЙ "РАССРОЧКА ЗИКМЕС" — НОВЫЙ БЛОК
 * ============================================================
 *
 * Этот блок НЕ изменяет существующий код (doGet, doPost, getPendingRows_,
 * markProcessed_, а также ImportStatement.gs) - только добавляет новые,
 * отдельные функции.
 *
 * ЧТО ДЕЛАЕТ:
 * Берёт строки из активного листа ТЕКУЩЕЙ таблицы ("Оплаты Зикмес"), у которых
 * метод оплаты (столбец E) = "Расчётный счёт", и для каждой такой строки
 * пытается закрыть соответствующий платёж в графике рассрочки во ВТОРОЙ
 * таблице ("Рассрочка Зикмес") - ПОИСК ИДЁТ ПО ВСЕМ ЛИСТАМ второй таблицы
 * без исключений (а не только по открытому/активному листу), либо
 * подсвечивает проблемные случаи цветом в столбце D первой таблицы для
 * ручной проверки.
 *
 * ЛОГИКА (см. итоговое согласованное описание):
 * 1. Берём строки текущего листа, где E = "Расчётный счёт".
 * 2. Если в строке есть АЙДИ (столбец C) - ищем эту строку (по столбцу A)
 *    в таблице рассрочки.
 *    - Если АЙДИ нет, но есть ФИО (столбец B) - ищем совпадение по ФИО
 *      (без телефона) в столбце B таблицы рассрочки, и если нашли -
 *      дозаполняем недостающее ФИО/АЙДИ обратно в таблицу 1.
 *    - Если и ФИО, и АЙДИ пустые - строку пропускаем.
 * 3. Если АЙДИ (известный или найденный по ФИО) НЕ найден в таблице рассрочки
 *    вообще - подсвечиваем столбец D в таблице 1 светло-жёлтым для ручной
 *    проверки, дальше эту строку не трогаем.
 * 4. Если АЙДИ найден в таблице рассрочки:
 *    a) Если в столбце M ИЛИ в столбце L (первой строки блока этого клиента,
 *       где также указаны АЙДИ/ФИО) есть значение - подсвечиваем столбец D
 *       в таблице 1 светло-розовым (как было в примере, строка 1662).
 *    b) Ищем среди всех строк блока этого клиента, НЕ СЧИТАЯ САМУ ШАПКУ
 *       (строку с ID/ФИО, обычно № платежа = 0 - она никогда не используется
 *       как цель записи, даже если её статус "Активный"), первую строку
 *       со статусом (столбец J) = "Активный":
 *       - если нашли: записываем дату (G) и сумму (I) из таблицы 1, меняем
 *         статус (J) на "Погашен".
 *       - если не нашли (все строки уже "Погашен"): добавляем новую строку
 *         сразу после последней строки этого блока (со сдвигом всего, что
 *         ниже), с датой, суммой и статусом "Погашен" (№ платежа в C можно
 *         оставить пустым).
 *
 * ЗАЩИТА ОТ ПОВТОРНОЙ ОБРАБОТКИ:
 * После каждой обработанной строки таблицы 1 в столбец G (новый, используется
 * только этим блоком - не путать со столбцом F, который заполняется
 * markProcessed_ из существующего кода) ставится отметка:
 * - "Рассрочка обработана" - если платёж был успешно закрыт или добавлена
 *   новая строка в таблице рассрочки.
 * - "Не найдено" - если АЙДИ/ФИО не нашлись ни на одном листе таблицы
 *   рассрочки вообще.
 * При следующих запусках строки с ЛЮБОЙ отметкой в столбце G полностью
 * пропускаются - скрипт их не проверяет и не ищет повторно. Это защищает
 * от повторного закрытия уже обработанных платежей при повторных запусках
 * скрипта на тех же данных.
 *
 * УСТАНОВКА: добавить как новый файл .gs в тот же проект Apps Script,
 * где уже лежат старый код и ImportStatement.gs. Никаких изменений в других
 * файлах не требуется - это полностью самостоятельный блок с собственной
 * точкой входа (processInstallments) и собственным HTML-интерфейсом.
 */

/**
 * Срабатывает при каждом открытии таблицы - добавляет кастомное меню
 * рядом с "Справка" в самой Google Таблице, с двумя пунктами:
 * импорт выписки банка и закрытие платежей по ЕРИП. Оба открываются
 * в модальных окнах, без перехода на отдельную веб-страницу.
 *
 * ВАЖНО: onOpen() - зарезервированная функция, на проект может быть только
 * одна. Если в проекте уже определена своя onOpen() где-то ещё - нужно
 * объединить содержимое в одну функцию (как уже сделано с doGet).
 */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Зикмес')
    .addItem('Импорт выписки банка', 'showImportDialog_')
    .addItem('Закрыть рассрочку по ЕРИП', 'showEripDialog_')
    .addToUi();
}

/**
 * Открывает модальное окно поверх таблицы с той же страницей
 * ImportStatementPage.html, что и отдельный веб-адрес ?page=import.
 */
function showImportDialog_() {
  var html = HtmlService.createHtmlOutputFromFile('ImportStatementPage')
    .setWidth(820)
    .setHeight(760);
  SpreadsheetApp.getUi().showModalDialog(html, 'Импорт выписки банка');
}

/**
 * Открывает модальное окно поверх таблицы с той же страницей EripPage.html,
 * что и отдельный веб-адрес ?page=erip - кнопка внутри окна вызывает ту же
 * processEripInstallments() и показывает тот же подробный отчёт.
 */
function showEripDialog_() {
  var html = HtmlService.createHtmlOutputFromFile('EripPage')
    .setWidth(640)
    .setHeight(720);
  SpreadsheetApp.getUi().showModalDialog(html, 'Закрытие рассрочки по ЕРИП');
}

/**
 * Роутер для GET-запросов этого блока (аналогично doGet_importRouter).
 * Открывается по тому же URL веб-приложения с параметром page=installments.
 */
function doGet_installmentsRouter(e) {
  var page = e.parameter.page;
  if (page === 'installments') {
    return HtmlService.createHtmlOutputFromFile('InstallmentPage')
      .setTitle('Закрытие платежей по рассрочке')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }
  return null;
}

/**
 * Роутер для отдельной страницы ЕРИП-обработки. Открывается по тому же URL
 * веб-приложения с параметром page=erip. Используется для случаев, когда
 * ЕРИП-платёжки вносятся в таблицу 1 вручную (не через импорт выписки) в
 * непредсказуемое время - эта страница позволяет в любой момент проверить
 * и закрыть только новые ЕРИП-строки без отметки в столбце G.
 */
function doGet_eripRouter(e) {
  var page = e.parameter.page;
  if (page === 'erip') {
    return HtmlService.createHtmlOutputFromFile('EripPage')
      .setTitle('Закрытие рассрочки по ЕРИП')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }
  return null;
}

/**
 * Точка входа для страницы ЕРИП. Обрабатывает ВЕСЬ активный лист (как
 * processInstallments() без аргументов), но фильтрует ТОЛЬКО строки
 * с методом "Ерип" - строки с "Расчётный счёт" не трогает совсем, даже
 * если они тоже не обработаны (для них используется отдельная страница
 * импорта/рассрочки).
 */
function processEripInstallments() {
  return processInstallments(null, null, INST_METHOD_VALUE_ERIP);
}

// ---- ID второй таблицы (Рассрочка Зикмес) ----
// ВРЕМЕННО: используется ID ТЕСТОВОЙ КОПИИ таблицы рассрочки для безопасного
// тестирования. Перед переносом в реальную работу замените обратно на ID
// боевой таблицы: 1rD1WChulpVdzwX6PZ1B4OI7PlmhfU3PqOl1iIbBM3WI
var INSTALLMENT_SPREADSHEET_ID = '1iY9um35AHLgSNVi6PTHfn8gpM2Gs5HlFSIcS9NWAEtA';

// ---- Столбцы в таблице 1 (Оплаты Зикмес) ----
var INST_SRC_COL_DATE = 1;   // A
var INST_SRC_COL_FIO = 2;    // B
var INST_SRC_COL_ID = 3;     // C
var INST_SRC_COL_AMOUNT = 4; // D
var INST_SRC_COL_METHOD = 5; // E
var INST_SRC_COL_MARK = 7;   // G - отметка об обработке рассрочки (НЕ путать со столбцом F,
                              // который заполняется отдельным процессом markProcessed_)

var INST_METHOD_VALUE = 'Расчётный счёт';
var INST_METHOD_VALUE_ERIP = 'Ерип';
var INST_MARK_PROCESSED = 'Рассрочка обработана';
var INST_MARK_NOT_FOUND = 'Не найдено';

// ---- Столбцы в таблице 2 (Рассрочка Зикмес) ----
var INST_COL_ID = 1;     // A
var INST_COL_FIO = 2;    // B
var INST_COL_NUM = 3;    // C - номер платежа
var INST_COL_PLAN = 4;   // D - сумма по плану
var INST_COL_DAY = 5;    // E
var INST_COL_YEAR = 6;   // F
var INST_COL_DATE = 7;   // G - дата факт. оплаты
var INST_COL_H = 8;      // H
var INST_COL_AMOUNT = 9; // I - сумма факт. оплаты
var INST_COL_STATUS = 10; // J - статус (Активный/Погашен)
var INST_COL_L = 12;      // L
var INST_COL_M = 13;      // M - товар

var INST_STATUS_ACTIVE = 'Активный';
var INST_STATUS_PAID = 'Погашен';

// Цвета подсветки (стандартная палитра Google Sheets)
var INST_COLOR_NOT_FOUND = '#FFF2CC';   // светло-жёлтый: АЙДИ не найден в таблице рассрочки
var INST_COLOR_HAS_NOTE = '#F4CCCC';    // светло-розовый: в столбце M есть запись (как пример 1662)

/**
 * ГЛАВНАЯ ФУНКЦИЯ. Запускается со страницы интерфейса (см. InstallmentPage.html)
 * или может быть запущена напрямую из редактора Apps Script.
 * Возвращает отчёт о том, что было сделано - для показа пользователю.
 *
 * @param {number} [onlyFromRow] Если указано - обрабатываются только строки
 *   таблицы 1, начиная с этого номера (1-based), остальные полностью
 *   игнорируются (даже не читаются построчно из srcRange). Используется при
 *   объединённом потоке "импорт выписки -> сразу закрытие рассрочки", чтобы
 *   не пересканировать весь лист, а взять только только что вставленные
 *   строки. Если не указано - обрабатывается весь лист, как раньше.
 * @param {number} [onlyToRow] Верхняя граница диапазона (включительно).
 *   Игнорируется, если onlyFromRow не указан.
 * @param {string} [methodFilter] Если указано - обрабатываются ТОЛЬКО строки
 *   с этим значением в столбце E (например, INST_METHOD_VALUE_ERIP, чтобы
 *   обработать только ЕРИП-платёжки, внесённые вручную). Если не указано -
 *   обрабатываются строки с ЛЮБЫМ из двух известных методов
 *   (INST_METHOD_VALUE или INST_METHOD_VALUE_ERIP), как раньше.
 *
 * ОПТИМИЗАЦИЯ ПРОИЗВОДИТЕЛЬНОСТИ: вместо повторного сканирования всех листов
 * таблицы рассрочки для КАЖДОЙ строки таблицы 1 (что приводило к превышению
 * лимита времени выполнения Apps Script на больших таблицах), строится ОДИН
 * индекс (ID/ФИО -> лист+строка) один раз в начале, читая данные каждого
 * листа ОДНИМ вызовом getValues(). После любой вставки новой строки на
 * каком-либо листе (insertRowAfter) индекс для ЭТОГО листа перестраивается
 * частично - сдвигаются только позиции на этом листе, остальные листы не
 * затрагиваются.
 */
function processInstallments(onlyFromRow, onlyToRow, methodFilter) {
  var startTime = Date.now();
  var srcSheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var srcLastRow = srcSheet.getMaxRows();
  var srcRange = srcSheet.getRange(1, 1, srcLastRow, 7).getValues(); // A:G (G = отметка обработки)

  var instSpreadsheet = SpreadsheetApp.openById(INSTALLMENT_SPREADSHEET_ID);
  var allInstSheets = instSpreadsheet.getSheets(); // ВСЕ листы второй таблицы, без исключений

  // Строим индекс один раз: для каждого листа считываем все строки одним
  // вызовом и заполняем idIndex / fioIndex. Значение - {sheetIdx, row}.
  var idIndex = {};   // "572097" -> {sheetIdx: 2, row: 5}
  var fioIndex = {};  // "лашкевич оксана васильевна" -> {sheetIdx: 2, row: 5}
  var sheetDataCache = []; // sheetDataCache[sheetIdx] = массив строк (значения) этого листа

  for (var s = 0; s < allInstSheets.length; s++) {
    var sheet = allInstSheets[s];
    var maxRows = sheet.getMaxRows();
    var lastCol = Math.max(sheet.getLastColumn(), INST_COL_M);
    var values = sheet.getRange(1, 1, maxRows, lastCol).getValues();
    sheetDataCache[s] = values;

    for (var i = 0; i < values.length; i++) {
      var idVal = values[i][INST_COL_ID - 1];
      var fioVal = values[i][INST_COL_FIO - 1];
      if (idVal !== '' && idVal !== null) {
        var idKey = String(idVal).trim();
        if (!idIndex[idKey]) idIndex[idKey] = { sheetIdx: s, row: i + 1 };
      }
      if (fioVal !== '' && fioVal !== null) {
        var cleanFio = extractFioOnly_(String(fioVal));
        if (cleanFio) {
          var fioKey = cleanFio.toLowerCase();
          if (!fioIndex[fioKey]) fioIndex[fioKey] = { sheetIdx: s, row: i + 1 };
        }
      }
    }
  }

  // Для каждого листа храним смещение позиций из-за вставленных строк,
  // чтобы индекс (построенный один раз, в ОРИГИНАЛЬНЫХ координатах листа)
  // оставался верным после insertRowAfter. offsetMap[sheetIdx] = массив
  // {afterRow: N, count: M}, где afterRow - ОРИГИНАЛЬНАЯ (до каких-либо
  // вставок) позиция строки, после которой произошла вставка M новых строк.
  var offsetMap = {}; // sheetIdx -> [{afterRow: N (оригинальная), count: M}, ...]

  // Возвращает актуальную (с учётом всех уже сделанных вставок) позицию
  // строки, чья ОРИГИНАЛЬНАЯ позиция (на момент построения индекса) была
  // originalRow.
  function adjustRow(sheetIdx, originalRow) {
    var shifts = offsetMap[sheetIdx];
    if (!shifts) return originalRow;
    var result = originalRow;
    for (var k = 0; k < shifts.length; k++) {
      if (shifts[k].afterRow < originalRow) {
        result += shifts[k].count;
      }
    }
    return result;
  }

  // Регистрирует вставку count новых строк, произошедшую сразу после
  // АКТУАЛЬНОЙ позиции afterRowActual (т.е. так, как только что вызвали
  // insertRowAfter(afterRowActual) на живом листе). Чтобы offsetMap
  // оставался в ОДНОЙ системе координат (оригинальной), сначала переводим
  // afterRowActual обратно в оригинальные координаты: ищем originalAfterRow,
  // для которого adjustRow(sheetIdx, originalAfterRow) === afterRowActual.
  // Так как сдвиги только положительные и применяются по возрастанию,
  // достаточно вычесть уже накопленное на текущий момент смещение.
  function registerInsert(sheetIdx, afterRowActual, count) {
    if (!offsetMap[sheetIdx]) offsetMap[sheetIdx] = [];

    // Накопленное смещение к МОМЕНТУ этой вставки (сумма всех count,
    // зарегистрированных раньше для строк выше или равных afterRowActual
    // в оригинальных координатах). Поскольку afterRow в уже сохранённых
    // записях - это оригинальные координаты, а afterRowActual - актуальная,
    // нужно найти оригинальный эквивалент итеративно: оригинал = actual,
    // затем вычитаем по каждой записи, чей (оригинал + накопленный_до_неё_сдвиг) < actual.
    var originalAfterRow = afterRowActual;
    var totalShiftSoFar = 0;
    for (var k = 0; k < offsetMap[sheetIdx].length; k++) {
      var entry = offsetMap[sheetIdx][k];
      // Актуальная позиция этой существующей записи на момент ЕЁ создания
      // была entry.afterRow + (сдвиг, накопленный до неё) - но так как записи
      // добавляются по порядку выполнения (а не по позиции), проще и надёжнее
      // сравнивать в уже актуальных координатах: entry.afterRow + totalShiftSoFar
      // даёт актуальную позицию этой записи СЕЙЧАС (после всех предыдущих).
      var entryActualNow = entry.afterRow + totalShiftSoFar;
      if (entryActualNow < afterRowActual) {
        totalShiftSoFar += entry.count;
      }
    }
    originalAfterRow = afterRowActual - totalShiftSoFar;

    offsetMap[sheetIdx].push({ afterRow: originalAfterRow, count: count });
  }

  var indexBuiltTime = Date.now();

  var report = {
    processed: 0,
    notFound: 0,
    hasNote: 0,
    filledFio: 0,
    filledId: 0,
    skippedNoData: 0,
    skippedAlreadyDone: 0,
    newRowsAdded: 0,
    details: [],
    timing: {
      sheetsScanned: allInstSheets.length,
      indexBuildMs: indexBuiltTime - startTime
    }
  };

  for (var r = 0; r < srcRange.length; r++) {
    var rowNumber1 = r + 1;

    // Если задан диапазон ограничения - пропускаем всё, что вне его
    if (onlyFromRow && rowNumber1 < onlyFromRow) continue;
    if (onlyToRow && rowNumber1 > onlyToRow) continue;
    var dateVal = srcRange[r][INST_SRC_COL_DATE - 1];
    var fioSrc = srcRange[r][INST_SRC_COL_FIO - 1];
    var idSrc = srcRange[r][INST_SRC_COL_ID - 1];
    var amountSrc = srcRange[r][INST_SRC_COL_AMOUNT - 1];
    var methodSrc = srcRange[r][INST_SRC_COL_METHOD - 1];
    var markSrc = srcRange[r][INST_SRC_COL_MARK - 1];

    var methodTrimmed = String(methodSrc || '').trim();
    if (methodFilter) {
      // Если указан конкретный фильтр - обрабатываем ТОЛЬКО строки с этим методом
      if (methodTrimmed !== methodFilter) continue;
    } else {
      // Без явного фильтра - принимаем любой из двух известных методов
      if (methodTrimmed !== INST_METHOD_VALUE && methodTrimmed !== INST_METHOD_VALUE_ERIP) continue;
    }
    if (amountSrc === '' || amountSrc === null) continue;

    if (markSrc !== '' && markSrc !== null) {
      report.skippedAlreadyDone++;
      continue;
    }

    var idStr = idSrc ? String(idSrc).trim() : '';
    var fioStr = fioSrc ? String(fioSrc).trim() : '';

    if (!idStr && !fioStr) {
      report.skippedNoData++;
      continue;
    }

    var foundRef = idStr ? idIndex[idStr] : null;

    if (!foundRef && fioStr) {
      var fioKey = fioStr.toLowerCase();
      if (fioIndex[fioKey]) {
        foundRef = fioIndex[fioKey];
        if (!idStr) {
          var sd = sheetDataCache[foundRef.sheetIdx];
          // Сначала проверяем ID в САМОЙ найденной строке - если ФИО найдено
          // в шапке собственного блока (как обычно), там уже есть свой ID,
          // и искать выше (в чужом блоке) НЕ нужно. Поиск выше нужен только
          // для редкого случая, когда ФИО вписано в подстроку без своего ID
          // (например "Семашко Виталий" внутри блока "Семашко Наталья").
          var ownIdVal = sd[foundRef.row - 1][INST_COL_ID - 1];
          var foundIdVal = (ownIdVal !== '' && ownIdVal !== null)
            ? ownIdVal
            : findBlockIdUpwards_(sd, foundRef.row);
          if (foundIdVal) {
            srcSheet.getRange(rowNumber1, INST_SRC_COL_ID).setValue(foundIdVal);
            idStr = String(foundIdVal).trim();
            report.filledId++;
          }
        }
      }
    }

    if (!fioStr && foundRef) {
      var sd2 = sheetDataCache[foundRef.sheetIdx];
      var foundFioRaw = sd2[foundRef.row - 1][INST_COL_FIO - 1];
      var cleanFoundFio = extractFioOnly_(String(foundFioRaw || ''));
      if (cleanFoundFio) {
        srcSheet.getRange(rowNumber1, INST_SRC_COL_FIO).setValue(cleanFoundFio);
        report.filledFio++;
      }
    }

    if (!foundRef) {
      srcSheet.getRange(rowNumber1, INST_SRC_COL_AMOUNT).setBackground(INST_COLOR_NOT_FOUND);
      srcSheet.getRange(rowNumber1, INST_SRC_COL_MARK).setValue(INST_MARK_NOT_FOUND);
      report.notFound++;
      report.details.push('Строка ' + rowNumber1 + ': АЙДИ ' + (idStr || '(нет)') + ' не найден ни на одном листе таблицы рассрочки');
      continue;
    }

    var instSheet = allInstSheets[foundRef.sheetIdx];
    var foundRow = adjustRow(foundRef.sheetIdx, foundRef.row);

    var mVal = instSheet.getRange(foundRow, INST_COL_M).getValue();
    var lVal = instSheet.getRange(foundRow, INST_COL_L).getValue();
    var hasNoteVal = (mVal !== '' && mVal !== null) || (lVal !== '' && lVal !== null);
    if (hasNoteVal) {
      srcSheet.getRange(rowNumber1, INST_SRC_COL_AMOUNT).setBackground(INST_COLOR_HAS_NOTE);
      report.hasNote++;
    }

    var blockEnd = findBlockEnd_(instSheet, foundRow);

    // Шапка блока (строка foundRow, где указаны ID/ФИО, обычно № платежа = 0)
    // НИКОГДА не используется как цель для записи факт. платежа - поиск
    // начинаем со следующей строки.
    var targetRow = null;
    for (var br2 = foundRow + 1; br2 <= blockEnd; br2++) {
      var statusVal = instSheet.getRange(br2, INST_COL_STATUS).getValue();
      if (String(statusVal).trim() === INST_STATUS_ACTIVE) {
        targetRow = br2;
        break;
      }
    }

    var dateStrForInst = formatDateDDMMYYYY_(dateVal);
    // Если платёж был закрыт методом "Ерип" (а не "Расчётный счёт") -
    // дописываем слово "ерип" перед датой в столбце G, чтобы визуально
    // отличать такие платежи от обычных.
    if (methodTrimmed === INST_METHOD_VALUE_ERIP) {
      dateStrForInst = 'ерип ' + dateStrForInst;
    }

    if (targetRow) {
      instSheet.getRange(targetRow, INST_COL_DATE).setValue(dateStrForInst);
      var amountCellTarget = instSheet.getRange(targetRow, INST_COL_AMOUNT);
      amountCellTarget.setNumberFormat('@STRING@');
      amountCellTarget.setValue(amountSrc);
      instSheet.getRange(targetRow, INST_COL_STATUS).setValue(INST_STATUS_PAID);
      srcSheet.getRange(rowNumber1, INST_SRC_COL_MARK).setValue(INST_MARK_PROCESSED);
      report.processed++;
      report.details.push('Строка ' + rowNumber1 + ' (' + (fioStr || idStr) + ') -> закрыт платёж в строке ' + targetRow + ' листа «' + instSheet.getName() + '»');
    } else {
      // Все платежи уже "Погашен" - добавляем новую строку сразу после
      // ТЕКУЩЕГО конца блока (с учётом уже накопленных сдвигов)
      instSheet.insertRowAfter(blockEnd);
      registerInsert(foundRef.sheetIdx, blockEnd, 1);
      var newRow = blockEnd + 1;
      instSheet.getRange(newRow, INST_COL_DATE).setValue(dateStrForInst);
      var amountCellNew = instSheet.getRange(newRow, INST_COL_AMOUNT);
      amountCellNew.setNumberFormat('@STRING@');
      amountCellNew.setValue(amountSrc);
      instSheet.getRange(newRow, INST_COL_STATUS).setValue(INST_STATUS_PAID);
      srcSheet.getRange(rowNumber1, INST_SRC_COL_MARK).setValue(INST_MARK_PROCESSED);

      report.newRowsAdded++;
      report.processed++;
      report.details.push('Строка ' + rowNumber1 + ' (' + (fioStr || idStr) + ') -> добавлена новая строка ' + newRow + ' листа «' + instSheet.getName() + '» (все платежи были закрыты)');
    }
  }

  report.timing.totalMs = Date.now() - startTime;
  return report;
}


/**
 * Находит последнюю строку блока клиента, начиная с startRow (где указан ID).
 * Блок заканчивается перед следующей строкой с заполненным ID в столбце A,
 * либо когда строка теряет содержательность (нет номера платежа и нет суммы).
 */
function findBlockEnd_(sheet, startRow) {
  var blockEnd = startRow;
  var maxScan = sheet.getMaxRows();
  for (var br = startRow + 1; br <= maxScan; br++) {
    var nextIdVal = sheet.getRange(br, INST_COL_ID).getValue();
    if (nextIdVal !== '' && nextIdVal !== null) {
      break;
    }
    // Строка считается частью блока, если есть хоть что-то содержательное:
    // номер платежа (C), план (D), ЛИБО уже записанные факт. дата/сумма/статус
    // (G/I/J) - последнее покрывает случай новых строк, добавленных этим же
    // скриптом в текущем или прошлом запуске (insertRowAfter создаёт полностью
    // пустую строку, и мы заполняем только G/I/J, не C/D).
    var numVal = sheet.getRange(br, INST_COL_NUM).getValue();
    var planVal = sheet.getRange(br, INST_COL_PLAN).getValue();
    var dateVal = sheet.getRange(br, INST_COL_DATE).getValue();
    var amountVal = sheet.getRange(br, INST_COL_AMOUNT).getValue();
    var statusVal = sheet.getRange(br, INST_COL_STATUS).getValue();

    var isEmpty =
      (numVal === '' || numVal === null) &&
      (planVal === '' || planVal === null) &&
      (dateVal === '' || dateVal === null) &&
      (amountVal === '' || amountVal === null) &&
      (statusVal === '' || statusVal === null);

    if (isEmpty) {
      break;
    }
    blockEnd = br;
  }
  return blockEnd;
}

/**
 * Извлекает только ФИО из строки вида "Иванов Иван Иванович   +375 29 111-11-11"
 * (отрезает номера телефонов, оставляет только текст до первого знака "+"
 * или первой цифры, которая выглядит как начало телефона).
 */
/**
 * Если ФИО найдено в строке, где столбец A (ID) пуст (например, кто-то
 * вручную дописал имя реального плательщика в одну из подстрок чужого
 * блока, без отдельного ID) - ищет ID в шапке ЭТОГО ЖЕ блока, поднимаясь
 * вверх до первой строки с непустым ID. Останавливается на первой найденной
 * непустой ячейке столбца A - это гарантированно шапка текущего блока,
 * так как блоки идут последовательно и не пересекаются.
 */
function findBlockIdUpwards_(sheetValues, startRow) {
  for (var i = startRow - 1; i >= 1; i--) {
    var idVal = sheetValues[i - 1][INST_COL_ID - 1];
    if (idVal !== '' && idVal !== null) {
      return idVal;
    }
  }
  return null;
}

function extractFioOnly_(s) {
  if (!s) return null;
  // отрезаем всё начиная с "+" (номер телефона) и схлопываем пробелы
  var cut = s.split('+')[0];
  cut = cut.replace(/\s+/g, ' ').trim();
  return cut || null;
}

function formatDateDDMMYYYY_(val) {
  if (val instanceof Date) {
    var d = val.getDate();
    var m = val.getMonth() + 1;
    var y = val.getFullYear();
    return (d < 10 ? '0' + d : d) + '.' + (m < 10 ? '0' + m : m) + '.' + y;
  }
  return String(val || '').trim();
}
